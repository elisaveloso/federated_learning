# federated_learning
This repository contains the code, experiments, and analysis from my undergraduate thesis on applying Federated Learning (FL) techniques to the agriculture sector.
